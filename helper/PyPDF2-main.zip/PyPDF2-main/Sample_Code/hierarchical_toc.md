# Example of hierarchical TOC from several pdf files

https://github.com/vb64/pdftoc
