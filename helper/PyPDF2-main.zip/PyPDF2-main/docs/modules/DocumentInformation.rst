The DocumentInformation Class
-----------------------------

.. autoclass:: PyPDF2.pdf.DocumentInformation
    :members:
    :undoc-members:
    :show-inheritance:
