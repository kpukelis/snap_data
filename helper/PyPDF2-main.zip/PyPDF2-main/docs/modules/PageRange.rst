The PageRange Class
-------------------

.. autoclass:: PyPDF2.pagerange.PageRange
    :members:
    :undoc-members:
    :show-inheritance:
