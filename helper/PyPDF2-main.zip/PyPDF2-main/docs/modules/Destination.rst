The Destination Class
---------------------

.. autoclass:: PyPDF2.pdf.Destination
    :members:
    :undoc-members:
    :show-inheritance:
