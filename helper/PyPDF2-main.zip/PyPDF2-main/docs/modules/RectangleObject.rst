The RectangleObject Class
-------------------------

.. autoclass:: PyPDF2.generic.RectangleObject
    :members:
    :undoc-members:
    :show-inheritance:
