The PdfFileReader Class
-----------------------

.. autoclass:: PyPDF2.pdf.PdfFileReader
    :members:
    :undoc-members:
    :show-inheritance:
