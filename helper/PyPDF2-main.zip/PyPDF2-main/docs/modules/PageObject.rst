The PageObject Class
--------------------

.. autoclass:: PyPDF2.pdf.PageObject
    :members:
    :undoc-members:
    :show-inheritance:
