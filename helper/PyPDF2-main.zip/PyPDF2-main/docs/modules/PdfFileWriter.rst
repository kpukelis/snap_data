The PdfFileWriter Class
-----------------------

.. autoclass:: PyPDF2.pdf.PdfFileWriter
    :members:
    :undoc-members:
    :show-inheritance:
