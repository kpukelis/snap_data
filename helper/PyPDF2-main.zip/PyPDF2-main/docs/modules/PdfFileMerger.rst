The PdfFileMerger Class
-----------------------

.. autoclass:: PyPDF2.merger.PdfFileMerger
    :members:
    :undoc-members:
    :show-inheritance:
