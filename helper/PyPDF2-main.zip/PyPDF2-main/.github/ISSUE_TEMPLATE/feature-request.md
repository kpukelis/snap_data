---
name: Request a Feature
about: What do you think is missing in PyPDF2?
title: ""
labels: Feature Request
assignees: MartinThoma
---

## Explanation

Explain briefly what you want to achive.

## Code Example

How would your feature be used? (Remove this if it is not applicable.)

```python
from PyPDF2 import PdfFileReader, PdfFileWriter

...  # your new feature in action!
```
