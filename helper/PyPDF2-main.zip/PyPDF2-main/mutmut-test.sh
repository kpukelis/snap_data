#!/bin/bash -e
pytest -x
